# LiveGood

# Elevator Pitch

Plenty of colleges force upperclassmen to live off-campus. However, most college students don't have enough experience and have trouble finding the desirable off-campus housing. LiveGood integrates useful information like rental price, distance to campus and utilities, and crime data along with a recommendation system and additional features like marketplace for subleasing to solve this problem.

# Problem

College students usually are forced to live off-campus after their first or second year due to the limitation of on-campus dorms (even some visiting scholars and grad students from other schools could face the same problem). Most students are not familiar with the apartments around campus, and it's hard for them to make a suitable choice. Colleges may provide some assistance, but in many cases this assistance fails to help students make the right decision. Without help from experienced upperclassmen, students often make suboptimal choices of where to live. A bad choice in the place to live could make the students spend more, sleep uncomfortably, and lead to all kinds of other problems. No one likes to be in such situations.

## Introduction to Domain

We’re working in a domain that is well understood by a broader audience.

# Solution

While students are tired of the research on different apartment choices, we help them do it wisely. We decide to develop an app called LiveGood to solve problems related to off-campus apartments. Students now have a place to gain integrated information (e.g. rental price, convenience index, safety index), first-hand information from experienced tenants about how good the apartment is, and advice from upperclassmen and our recommendation system based on students' profile and preferences. This could help them spend less time and make it easier to find the best place to live.

## Architecture Overview

- Mobile app: React Native, Redux, ~~TypeScript~~ JavaScript
- Backend: serverless cloud functions (AWS Lambda) written in Go
- Database: PostgreSQL
- Data Scraping: Python with Scrapy & Selenium
- Recommendation System: either a deep learning intelligent system in Python or a simple one that weighs users' preferences
- APIs: Zillow API, Google Place API, and FBI Crime Date Explorer API for getting rent prices, safety websites/police department data for crime map and safety index

## Features

- Interactive map that shows major apartments locating near the school which is selected by user through a search bar or by autolocating.
- Showing useful information like rent, safety index (safety index is evaluated by the data we get from the local Police Department), distances of apartments.
- Provide a candidate list sorted by some recommendation algorithm or features selected by user like rent, safety, distance and so on.
- Recommendation system where users can rate their apartments and recommend suitable apartment to others based on their preferences.
- ~~Comment and discussion system to help users get first-hand information from other renters.~~
- ~~Marketplace for renters to advertise for subleasing and secondhand deals.~~

## Wireframes

- By [Figma](https://www.figma.com/)

**Login Page**

![Log In Page](image/Login.png)

**Map View Page**

- Viewing apartments in a map

![Map View Page](image/MapView.jpg)

**More Info About Apartment Page**

- Linked to Map View Page

![More Info Page](image/MoreInfo.jpg)

**Apartment List Page**

- Another way of viewing apartments

![List](image/List.jpg)

**Personal Profile Page**

- User Profile

![Profile](image/Profile.jpg)

## User Stories

As a sophomore who is forced to live off-campus in the following semester, I would like to get advice on which apartment
near the university suits me most in terms of my cost and safety concerns. I would also want to know the comments from
people who actually live in those apartments so that I can get a more accurate feedback. Here're the steps I'll take:

- First I find my college through the search bar, or the app can autolocate my position and school.
- Then I can see the candidate list. Since I regard the rent as important, I select "rent" as the feature to sort by. Now I can see the most economical apartments around my school recommended by the system and upperclassmen.
- Now I'm interested in what people say about these aprtments. Clicking on the apartment, I can see ~~the comments people made on~~ the safety and convenience of this apartment. All things seem good, so I'll go to the website of this apartment to see its plans.

# Viability

## Hardware

All we need are computers that can develop software and mobile phones that can help us test our app on real devices. We have them.

## APIs

- Integration with [housing APIs](https://www.attomdata.com/news/attom-insights/best-apis-real-estate/) like Zillow's API to get the rent prices of apartment. Register to use.
- Integration with crime data like [this](https://crime-data-explorer.fr.cloud.gov/api) from FBI to get detailed information of crimes. It is free to use and covers almost all areas and years in United States.
- Integration with Google Place API to get restaurants, market, gas stations, and bar information around some apartment to give a comprehensive evaluation of the apartment for the users.

## Tools

- VSCode: write and edit code
- React, React Native: front-end framework
- Redux: front-end state management
- ~~TypeScript~~ JavaScript: write front-end codes
- AWS Lambda, PostgreSQL: backend tools
- Go: backend cloud functions written in Go
- Python: used for web scraping (if necessary) and building deep learning recommendation system

## Proof of Concept

- It’s clear that our project is technically viable. All the tools we use are viable, easy-to-learn with detailed documents. Data are available and free online from provided APIs for this project.

- Initialy, we will calculate the overall score of each apartment for recommendation system by assigning weight to different indices according to user's preference. This is the basic implementation the algorithm to recommend the apartment, and we will update the algorithm in the future (Machine Learning/Deep Learning).

- To be more specific, we may need to first develop the Proof of Concept of the following modules:
  - The module for automatically pinning a point in a map;
  - The module for Zillow API;
  - The module for building the user commnuity and comments area;
  - The module for suggestion system.

# Difficulty

The project difficutly lies in a proper range. We have core features that support the whole idea as well as chanllenge thoughts to help our service bemore more accurate and our product easier to use .

- Interactive map and Real estate data. Open APIs like Zillow and Mapbox offer data support in a very developer-friendly way.
- A user-friendly mobile app as well as webpage could be built with highly integrated tools like React Native. Some of the group members have experience in the area. This could be a challenge but not a major one.
- A robust recommendation system is needed to provide recommendation service to our users. Feature selection methods are adapted in most of the competitors' products. Build such a system need specific care towards the selection, which could involve tons of efforts. Deep learning based recommendation is a more fancy way to do it, which could be a great chanllenge. Considering the machine learning backgroud of our group, such a chanllenge could be acceptable.
- ~~A safe marketplace for subleasing and other transcations is planned~~. Safety should always be the first priority in the product design. We are new to this field and we are learning to apply mature solution in the industry to perfect our product.

# Market Research

## Users

Almost everyone in the school, especially junior or transfer students who don't have lots of experience in house hunting, can use our app to find off-campus housing that would match their expectations. They don't have to be an expert to negotiate with the renting office because we can build a bridge between them. Since our main target is college students, once we verify their identity, users can get access to all the features in the app.

## Competition

Similar apps like Zillow and ApartmentList could be our main competitors. However, we can differentiate our products by focusing more on college students (include their college credentials), adding the safety index feature which is an indication of the area safety issue, and recommendation system and marketplace features. The reason why we incorporate the safety index feature is that safety, for some students, is the most important concern in their house-hunting process.

# Roadmap

<https://github.com/jhu-oose/2019-group-Live-Good/projects/1>
