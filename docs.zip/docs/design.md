# Design

## Architecture

<!-- Is this a web application, a mobile application (React Native, iOS, Android?), a desktop application, and so forth? How do the different components (client, server, and so forth) communicate? Don’t simply list tools; tell a story. You must discuss what these tools are, why you chose them, and how to configure them -->

We are going to develop a **mobile app** with user interface built with React Native and backend functions written in Go and deployed to AWS Lambda. The detail of what these tools is listed below.

The mobile UI part (React Native) will use Redux to call backend function with the Axios package. Then, Axios will make http requests to the backend functions that we deployed to AWS Lambda. With AWS Lambda, we don't need to setup our server manually, and we only need to worry about how to write our backend functions. In our backend function, we will use it to fetch data from external Zillow APIs, do database CRUD operations with PostgreSQL service also provided by AWS, and many other basic stuffs like login and searching.

(According to our plan, we would first develop a cross platform mobile app. If time permits, we might consider develop the same app on the web.)

## Tools Outside the Toolbox

<!-- For each tool: What is it? Why did you choose it? Where do you get it? How do you learn it? Follow the model of how we presented the tools in the Toolbox. Cute original drawings encouraged. -->

### React Native

React Native, maintained by the developers at Facebook and Instagram, could be the future of mobile development. The reason why we are choosing React Native is because (1) it provides compatibility of cross platforms, which would be easier for us to develop and test with; (2)it could help us to reduce development cycles with a lot of external supports and en source components; (3) updates would take much less time to complete as React Native enables us to push updates o the users' phone without going through app store update cycle; (4) some of our members have rich experience on React Native, which could save us a lot of time before configuring and start working on the frontend.

### Redux

Redux is an open-source JavaScript library for managing application state. With Redux, we can have a centralized store to manage the states of all the pages in the front end. We can have separate pure front end view part from actions that communicate with backend and reducers that update our centralized store, thus making our front end more structured and easy to manage.

### ~~TypeScript~~

~~TypeScript is an open-source programming language made by Microsoft and is the superset of JavaScript (meaning that code in JS can also work in TS). What it makes TS distinguished is that it adds type which is missing in JS, making development and especially debugging easier and faster.~~

### JavaScript

We decided to switch back to JavaScript which is inside the toolbox because TypeScript is a little bit hard to understand and is not necessary in our current project (right now we don't have a huge scale).

### Backend: AWS Lambda - Golang

With AWS Lambda, we could run our code without managing a backend server by ourselves, which is convenient and cheap for a small team developers. Besides, setting up and configuring the virtual server only takes the time to register an AWS account, almost no time cost for setting up.

Golang, designed by Google, is a programming language becoming more and more popular for backend use. Because it's the combination of interpreted, dynamically-typed language and statically-typed compiled langauge, it has their advantages of high effeciency and safety. Moreover, Golang can handle concurrency with simplicity and speed, which could be of great help for future software development.

### Database - PostgreSQL

We are using PostgreSQL, a relational database system, to store and handle our data of apartments information, user profiles, etc. The reason why we choose PostgreSQL is because (1) it's reliable and feature robust with high performance; (2) it has complete and up-to-date documentation and good community support; (3) it's easy to configure and a SQL database would be more intuitive for us to handle regarding the data we want to store; (4) we have previous experience on this database.

### Data Scraping - Python

Python offers great help for web crawling: we could use Scrapy and Selenium for both scraping the static and dynamic websites. The reason why we are choosing this is because some of our members have used these packages before and could start working on data scraping right away.

### External API - Zillow

The Zillow API could provide real estate, home value, profile and mortgage data to our app. It's designed to supplement agent profiles and directories with customer reviews to assist the consumer in choosing the best agent for particular needs.

The reason why we are choosing this API for our app is because (1) the data it is proveding with is highly related to our needs; (2) Zillow API provides a large number of reviews o consumers as hundreds of thousands of consumers have posted reviews on Zillow; (3) one of the most important reasons: it's free.

Implementing Zillow API is not hard: all we need is an account and to read the API documentation.

### External API - FBI Crime Data

[Link to API](https://crime-data-explorer.fr.cloud.gov/api)

This API gives us access to the crime data around the country, and we can call it with RESTful API to retrieve the crime data. The API returns a json object that contains crime information in a given area.

The reason we choose this API is (1) the data is detailed including location, type, and other descriptions of the crime; (2) the data covers almost all areas and years in United States since it started recording; (3) it's free.

### External API - Google Place

This API gives us some restaurant, market, gas station around a certain place, which we could use to show detailed information on some apartments.

## Class Diagram

![Class Diagram](image/UML.jpg)
