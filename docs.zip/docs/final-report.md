# Final Report

**⚠️  Remember to also fill in the individual final reports for each group member at `https://github.com/jhu-oose/2019-student-<identifier>/blob/master/final-report.md`.**

**⚠️  You don’t need to do anything special to submit this final report—it’ll be collected along with Iteration 6.**

# Revisiting the Project Proposal & Design

<!--
How did the Project Proposal & Design documents help you develop your project?

What changed in your project since you wrote the initial version of those documents?
-->

<!--
The project proposal is helpful. It not only gives a general idea of what our project will be like, but also foresees
some problems that we actually encountered later during the implementation. For example, front-end tools like React
Native could be hard to start for beginners, and this takes time to get familiar with. Information provided by the data
is not sufficient for building an advanced recommendation system. Throughout the process, we are following the roadmap
we created, while updating after each single iteration. Although our app doesn't look quite the same with our wireframes,
it realizes most pages and functionality we proposed to have. All the toolboxes are used and every member is learning
new things. Most of the features are implemented as we move along, and the rest of them can be added for later iterations.
We are confident that our app could solve the problem we presented in the proposal.
-->

The project proposal gives us a general idea of what our project looks like at the beginning of the devlopment. Plus, it helps in identifying the potential problems we would encounter in the developing process.

For example, we spared additional time to get familiar with the tools we will use, such as React Native, which is known to be hard to master for beginners. We also met the problem that the information we collect is not sufficient for building an advanced recommendation system, and we bypassed this problem by applying a rule-based recommendation system.

We followed our roadmap and updated it in time according to our current progress after each iteration. Though inevitably, our app does not look the same as our wireframes indicated, we sucessfully implemented most features and functionalities we proposed. We utilized tools introduced in the toolbox, and each team member mastered something new.

We implement the main features as planned in the proposal. Some minor but interesting features, like diverse factors in the recommendation system, are added as we moved along. We believe our app would satisfy all the requirements presented in the proposal.

<!--
The design document provides more detailed information for the implementation. It introduces the advanced toolboxes we used
extensively, including the introduction and benefits. This gives us a better idea of how and where to use these technologies.
The external APIs are mostly used (except FBI), and proves to be simple to call and provides as much information as it
is available for our backend databases. We didn't follow the class diagram quite a lot, but it still gives us a sense of
where to create a class and how to link different parts.
The biggest change since we wrote the initial version of those documents is the order we implemented our app. Without
these, we didn't have a direction of where to start, because everything is from scratch and there are just too many things
to work on. Later after we wrote the documents, we have a clear plan of what to do for each iteration, or it makes this
process way shorter. The documents also give us a sense of the workload of each parts, making it easier to assign separate
work to each team member. The connection between each parts is clear enough that we didnt' spend too much time worrying about
connecting different functions. As a summary, our project is still relatively small, but proposal and design already
generated a huge impact along the way.
-->

The design document gives detailed information for our implementation, introduces the advanced tools extensively. It serves as an excellent guide for a rookie developer.

In our data collection procedure, we utilized many external APIs as well as web crawlers for apartment information, nearby places, and criminal records. The data fulfilled our databases and made our app more reliable. Furthermore, it allowed us to construct a trustworthy recommendation system. Though we did not follow the class diagram exactly, we still get a sense of how to link different parts.

We made significant changes to the order we implemented our app. The initial version gave us a direction on what to explore next, and we adjusted it as our vision became more clear. In each iteration, we evaluated our progress in time and discussed an organized plan for the next iteration. Writing these documents made many things comfortable, such as assigning tasks to each team member and balancing the workload of each iteration.

As a summary, our project is relatively small, but it shows the potential to be a great, useful app.

![UML diagram](https://github.com/jhu-oose/2019-group-Live-Good/blob/master/docs/image/UML.jpg)

# Challenges & Victories

<!--
In software engineering things rarely go as planned: tools don’t work as we expect, deadlines aren’t met, debugging sessions run longer than we hoped for, and so forth.

What were some of the biggest challenges you found when developing your project? How did you overcome them?
-->

Challenges:

For database part, it is really challenging to get the correct floor plan data and sometimes the price data for each apartment in our list because some leasing office won't post them online. For this kind of information, we just leave them as not available because getting those informaiton may take us a lot of time and that is not the point of this class. In real development world, one of the possible solutions may be hire someone to get those information either by calling the leasing office or go to the specific place to do the research.

For frontend, it's challenging for beginners relatively, since the layout has to be modified a lot of times in order to realize the best effects. Things like size and distance from screen side sound pretty easy, but in real practice they are the most time consuming work to do. The connection between the database and frontend is implemented by Redux, which uses axios to make HTTP requests to call REST APIs, and this connection process can also be hard if the inputs don't match the parameters required.

Victories:

For database, we do get a lot of useful information by calling Google Place API, Google Geocoding API and Zillow API. The good thing of those APIs is that they are free to use and once we get the data, we can store them in our database and make calls from there, which can make the response more efficient in the end.

For backend, we successfully built all the APIs on AWS Lambda, which fetch data from the database and respond to frontend requests with certain operations.

For frontend, we designed our screen the same pattern as Uber's black and white style, which looks clean and simple. We successfully used map from Google and added necessary information on to the map. This makes the app easier to use. The profile page could save individualized preferences from users and displayed recommendations based on preferences.

# Experience with Tools

<!--
Which tools did you learn to like? Why?

Which tools did you learn to dislike? Why? And what other tools would you have replaced them with if you were to start all over again?
-->

Backend - AWS Lambda:

This is a very useful tool for the reason that this provides a serverless service for a small development team to build up the backend. The platform provides Lambda and API Gateway for running backend code and deploying APIs to be part of the server. This platform simplify the maintainance of backend server to be multiple APIs, which helps the backend to better clarify and structure customer needs within modules. The platform is always consistent and provides testing techniques for the development team. As a new popular tool in the real industry world, AWS Lambda provides us a lot of convenience during the development and we really like it.

Frontend - React Native, Redux:

In class we were introduced to React, and in our app we used React Native, which is developed by Facebook and supports native frontend user interefaces, just like the apps developed with Swift and Android. Since React Native is pretty sophisticated, we can find a plethora of component libraries online, which provides a wide range of options for us to build our frontend interfaces. React Native itself is very similar to React, so getting started with it is not extremely difficult. However, Redux was challenging for beginners -- it has a steep learning curve at the beginning. After we became proficient in Redux, it showed the benefits of using it. Since Redux provides a centralized state management, we can use it to access the whole app's state from any screen by simply connecting the screen with Redux. In addition, with Redux, we can easily split the frontend into view (screen or component files) and controllers and models in Redux files. In this way, the whole frontend becomes cleaner and easy to maintain.

# Iteration 7 & Beyond

<!--
Where would you take your project from here? What features would you add to make your application even more awesome? How would you prioritize that work?

Update the project board with tasks for a hypothetical Iteration 7.
-->

- For database part, we need to incorporate more information about places near the apartment, which can help the user get a better recommendations from using our app.
- We have the structure to provide a larger scale of schools, so we would like to have more data input from other schools to provide service to a larger customer group.
- We would like to add community communication features (e.g. comments or a mini forum) for further development, which could provide the user an atmosphere of community and help them sublease their apartment.
- We also want to beautify our frontend even more for a better user experience. This is also necessary when our app supports more advanced functionality in the future.
- We might also add a market part for listing subleases. This can help students who leave during the breaks to sublease their apartments to other students who visit the campus during the break.

# A Final Message to Your Advisor

<!--
What did you like in working with them?

What do you think they need to improve?

And anything else you’d like to say.
-->

We would like to express our great gratitude to @Pranavs05, who helped us a lot for leading us the direction on software development. He guided us well on what we should put our most attention when developing and gave us a lot of useful suggestions along the way. We really like to work with him and have learned a lot from his advices. Thanks for his generous help!
